package tn.pi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
