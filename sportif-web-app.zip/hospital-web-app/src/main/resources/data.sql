insert into patient (id,nom,date_naissance,malade,score)
values(10001,'Monji',CURRENT_DATE(),true,1234);
insert into patient (id,nom,date_naissance,malade,score)
values(10002,'Mounira',CURRENT_DATE(),false,1275);
insert into patient (id,nom,date_naissance,malade,score)
values(10003,'Aziza',CURRENT_DATE(),true,1834);
insert into patient (id,nom,date_naissance,malade,score)
values(10004,'Midou',CURRENT_DATE(),false,1964);