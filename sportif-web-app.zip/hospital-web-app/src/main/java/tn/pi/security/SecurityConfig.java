package tn.pi.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import tn.pi.component.CustomAuthenticationSuccessHandler;
import tn.pi.service.CustomUserDetailsService;

@Configuration
public class SecurityConfig {
    private final CustomUserDetailsService customUserDetailsService;
    private final CustomAuthenticationSuccessHandler customSuccessHandler;

    public SecurityConfig(CustomUserDetailsService customUserDetailsService, CustomAuthenticationSuccessHandler customSuccessHandler) {
        this.customUserDetailsService = customUserDetailsService;
        this.customSuccessHandler = customSuccessHandler;
    }
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .formLogin(form -> form
                        .loginPage("/login") // Page de connexion
                        .loginProcessingUrl("/login")
                        .successHandler(customSuccessHandler)
                        .permitAll()
                )
                .logout(logout ->
                        logout
                                .permitAll()
                                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                                .logoutSuccessUrl("/")
                                .deleteCookies("JSESSIONID")
                                .invalidateHttpSession(true)
                )
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/admin/**","/adherent/**","/coach/**","/profile/**").hasRole("ADMIN")
                        .requestMatchers("/coach/**").hasRole("COACH")
                        .requestMatchers("/adherent/**","/profile/**").hasRole("ADHERENT")
                        .requestMatchers(
                                "../css/**",
                                "/webjars/**",
                                "/static/css/**",
                                "/images/**",
                                "/js/**",
                                "/public/**",
                                "/Home",
                                "/homeCli",
                                "/activitiesCli",
                                "/aboutUs",
                                "/contactUs",
                                "/activity/details",
                                "/login",
                                "/signup/**",
                                "/saveMember",
                                "/images/",
                                "/logout",
                                "/"
                        ).permitAll()
                        .anyRequest().authenticated() // Toutes les autres routes nécessitent une authentification
                )
                .build();
    }




    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(customUserDetailsService).passwordEncoder(passwordEncoder());
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class).build();
    }
}
