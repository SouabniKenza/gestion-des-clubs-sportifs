package tn.pi.enums;

public enum Role {
    ADMIN,COACH,ADHERENT
}
