package tn.pi.enums;

public enum Paiement_Methode {
    CASH,           // Paiement en espèces
    CREDIT_CARD,    // Paiement par carte de crédit
    DEBIT_CARD,     // Paiement par carte de débit
    CRYPTOCURRENCY, // Paiement en cryptomonnaie
}
