package tn.pi.enums;

public enum PaymentStatus {
    PAID,      // Paiement effectué
    PENDING,   // En attente
    OVERDUE    // En retard
}