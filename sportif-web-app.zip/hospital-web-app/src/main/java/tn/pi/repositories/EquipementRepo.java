package tn.pi.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tn.pi.entities.Activity;
import tn.pi.entities.Equipement;

import java.util.List;

public interface EquipementRepo extends JpaRepository<Equipement, Long> {
    Page<Equipement> findByNameContains(String keyword, Pageable pageable);
    @Query("SELECT e FROM Equipement e JOIN e.activities a WHERE a.id = :activityId")
    Page<Equipement> findByActivities_Id(@Param("activityId") Long activityId, Pageable pageable);

}
