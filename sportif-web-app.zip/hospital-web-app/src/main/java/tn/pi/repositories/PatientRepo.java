//package tn.pi.repositories;
//
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//import tn.pi.entities.Patient;
//@Repository
//public interface PatientRepo extends JpaRepository<Patient, Long> {
//    Page<Patient> findByNomContains(String keyword, Pageable pageable);
//}
//
////interface PatientRepo (DAO)
////Fournit des méthodes CRUD automatiques grâce à JpaRepository