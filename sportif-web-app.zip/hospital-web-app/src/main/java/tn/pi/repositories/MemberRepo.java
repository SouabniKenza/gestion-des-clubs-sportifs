package tn.pi.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tn.pi.entities.Activity;
import tn.pi.entities.Member;
import tn.pi.enums.Role;

import java.util.List;
import java.util.Optional;


@Repository
public interface MemberRepo extends JpaRepository<Member, Long> {
    // Recherche par nom et rôle avec pagination
      Page<Member> findByNomContainsAndRole(String keyword, Role role, Pageable pageable);

    // Recherche des membres associés à une activité spécifique
    @Query("SELECT m FROM Member m JOIN m.activities a WHERE a.id = :activityId")
    Page<Member> findByActivities_Id(@Param("activityId") Long activityId, Pageable pageable);


    //Chart.js

    //Compter le nombre de membres par rôle
    @Query("SELECT COUNT(m) FROM Member m WHERE m.role = :role")
    long countByRole(@Param("role") Role role);


    //Activité la plus populaire
    @Query("SELECT a.name, COUNT(m) AS memberCount FROM Member m JOIN m.activities a GROUP BY a.name ORDER BY memberCount DESC")
    List<Object[]> findMostPopularActivities();

    Optional<Member> findByUsername(String username);

    boolean existsByUsername(String username);

    @Query("SELECT m FROM Member m " +
            "WHERE (:activityId IS NULL OR NOT EXISTS (SELECT 1 FROM m.activities a WHERE a.id = :activityId)) " +
            "AND (:keyword IS NULL OR LOWER(m.nom) LIKE LOWER(concat('%', :keyword, '%'))) " +
            "AND (:role IS NULL OR m.role = :role)")
    Page<Member> findByActivitiesNotContainingAndNameContainingAndRole(
            @Param("activityId") Long activityId,
            @Param("keyword") String keyword,
            @Param("role") Role role,  // Supposons que "role" est une enum ou un type personnalisé
            Pageable pageable);

    @Query("SELECT DISTINCT m FROM Member m JOIN m.activities a WHERE a IN :activities")
    Page<Member> findMembersByActivities(@Param("activities") List<Activity> activities, Pageable pageable);

    Page<Member> findByNomContains(String keyword, PageRequest of);

    @Query("SELECT m FROM Member m " +
            "WHERE (:activityId IS NULL OR EXISTS (SELECT 1 FROM m.activities a WHERE a.id = :activityId)) " +
            "AND LOWER(m.nom) LIKE LOWER(concat('%', :keyword, '%'))")
    Page<Member> findByActivityAndNameContaining(
            @Param("activityId") Long activityId,
            @Param("keyword") String keyword,
            Pageable pageable);
}

