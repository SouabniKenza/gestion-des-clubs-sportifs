package tn.pi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tn.pi.entities.Horaire;
import tn.pi.enums.DayOfWeek;

import java.util.List;

@Repository
public interface HoraireRepo extends JpaRepository<Horaire, Long> {

    // Trouver tous les horaires associés à une activité spécifique, triés par jour et heure de début
   @Query("SELECT h FROM Horaire h WHERE h.activite.id = :activityId ORDER BY h.jour, h.heureDebut")
   List<Horaire> findOrderedHorairesByActivite_Id(@Param("activityId") Long activityId);

    // Vérifier si un horaire chevauche un autre horaire pour une activité donnée
    @Query("""
           SELECT COUNT(h) > 0 FROM Horaire h
           WHERE h.activite.id = :activityId
           AND h.jour = :jour
           AND ((h.heureDebut <= :heureFin AND h.heureFin >= :heureDebut))
           """)
    boolean existsOverlappingHoraire(@Param("activityId") Long activityId,
                                     @Param("jour") String jour,
                                     @Param("heureDebut") String heureDebut,
                                     @Param("heureFin") String heureFin);

    // Récupérer tous les horaires par jour pour un affichage global
    @Query("SELECT h FROM Horaire h ORDER BY h.jour, h.heureDebut")
    List<Horaire> findAllOrderedByJourAndHeureDebut();

   List<Horaire> findByActivite_Id(Long activityId);

    @Query("SELECT DISTINCT h.jour FROM Horaire h")
    List<String> findDistinctJours();

    List<Horaire> findByJour(DayOfWeek jour);

    List<Horaire> findByActivite_IdAndJour(Long activityId, DayOfWeek jour);

}
