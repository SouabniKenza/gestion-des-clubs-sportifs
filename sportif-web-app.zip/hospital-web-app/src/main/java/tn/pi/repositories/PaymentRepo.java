package tn.pi.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tn.pi.entities.Member;
import tn.pi.entities.Payment;

import org.springframework.data.domain.Pageable;
import tn.pi.enums.PaymentStatus;

import java.util.List;


@Repository
public interface PaymentRepo  extends JpaRepository<Payment, Long> {
    Page<Payment> findByMember_Id(Long memberId, Pageable pageable); // Paiements d'un membre spécifique


    Page<Payment> findByStatus(PaymentStatus paymentStatus, PageRequest of);

    List<Payment> findByMember_Id(Long memberId);


    List<Payment> findByMember(Member member);
}