package tn.pi.component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import tn.pi.entities.Member;

import java.io.IOException;

@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException, IOException {
        Member user = (Member) authentication.getPrincipal();
        String role = user.getRole().toString();
        // Ajouter les informations de l'utilisateur dans la session
        request.getSession().setAttribute("CurrentUser", user);

        if (role != null) {
            switch (role) {
                case "ADMIN" -> response.sendRedirect("/admin/home");
                case "COACH" -> response.sendRedirect("/");
                case "ADHERENT" -> response.sendRedirect("/");
                default -> response.sendRedirect("/");
            }
        } else {
            response.sendRedirect("/uiii");
        }
    }
}
