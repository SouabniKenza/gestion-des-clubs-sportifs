package tn.pi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import tn.pi.entities.Member;
import tn.pi.repositories.MemberRepo;

import java.time.LocalDate;

@SpringBootApplication
//using lombok but not best way
//@RequiredArgsConstructor
public class HospitalWebAppApplication {
	//@Autowired
	//private final PatientRepo patientRepo;
	//best way to do is to create a constructor


	public static void main(String[] args) {
		SpringApplication.run(HospitalWebAppApplication.class, args);
	}
	// create init method
	//@Bean bch meyanserich
//	public CommandLineRunner init(PatientRepo patientRepo) {
//		return args -> {
//			/**
//			 * Begin transaction
//			 */
//
//			//using default constructor
//			Patient patient1 = new Patient();
//			patient1.setNom("Aziz");
//			patient1.setDateNaissance(LocalDate.now());
//			patient1.setMalade(false);
//			patient1.setScore(324);
//			patientRepo.save(patient1);
//
//			//using params constructor
//			Patient patient2 = new Patient(null,"Ali",LocalDate.now(),true,9887);
//			patientRepo.save(patient2);
//
//			//using Lombok
//			Patient patient3= Patient.builder()
//					.nom("Sarra")
//					.dateNaissance(LocalDate.of(2001,12,3))
//					.score(56365)
//					.malade(false)
//					.build();
//			patientRepo.save(patient3);
//
//
//
//
//		};
//	}
}