package tn.pi.entities;

import lombok.*;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import tn.pi.enums.Paiement_Methode;
import tn.pi.enums.PaymentStatus;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "member_id", nullable = true)
    private Member member; // Membre ayant effectué le paiement

    @Enumerated(EnumType.STRING)
    private Paiement_Methode paymentMethod = Paiement_Methode.CASH;// Méthode (espèces, carte, virement)

    private  String CardNumber;
    private Double amount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status =PaymentStatus.PENDING; // Statut du paiement (PAID, PENDING, OVERDUE)

    @NotNull
    private LocalDate paymentDate = LocalDate.now();
}
