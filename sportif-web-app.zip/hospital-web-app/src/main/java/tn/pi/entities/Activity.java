package tn.pi.entities;
import jakarta.persistence.Entity;
import lombok.Getter;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
//@ToString
@Builder
public class Activity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected  long id;
    @NotBlank(message = "Le nom de l'activité ne peut pas être vide")
    protected  String name;
    protected  String description;
    @NotBlank(message = "La location ne peut pas être vide")
    protected  String location;

    @ManyToMany(mappedBy = "activities")
    private List<Member> members = new ArrayList<>();
    @NotNull
    protected Double price;
    @ManyToMany(mappedBy = "activities")
    @ToString.Exclude
    private List<Equipement> equipments = new ArrayList<>();
    public void  addMember(Member member) {
        members.add(member);
    }
    public void  removeMember(Member member) {
        members.remove(member);
    }


    @Lob
    @Column(length = 1048576)
    protected byte[] image;

    @Transient
    private MultipartFile imageFile;
}

