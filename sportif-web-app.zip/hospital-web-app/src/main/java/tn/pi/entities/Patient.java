//package tn.pi.entities;
//
//import jakarta.persistence.*;
//import jakarta.validation.constraints.Min;
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.Size;
//import lombok.*;
//
//import java.time.LocalDate;
////Entity indique que cette classe est une table
//@Entity
//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
//@Builder
//public class Patient {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    @NotBlank(message = "Le nom ne peut pas être vide")
//    @Size(min = 4, max = 50)
//    private String nom;
//    private LocalDate dateNaissance;
//    private boolean malade;
//    @Min(100)
//    private int score;
//}
//
////Hibernate génère une table Patient dans la base MySQL avec les colonnes correspondantes (id, nom, dateNaissance, malade, score).