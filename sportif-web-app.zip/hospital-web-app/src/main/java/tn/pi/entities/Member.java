package tn.pi.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.validator.constraints.Range;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import tn.pi.enums.Role;

import java.time.LocalDate;
import java.util.*;

// Entity indique que cette classe est une table
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Member implements UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "name can't be empty")
    private String nom;

    @NotBlank(message = "last name can't be empty")
    private String prenom;

    @Email(message = "enter a valid email")
    private String email;

    @NotBlank(message = "please enter password")
    private String password;

    @Past(message = "Birthdate must be in past")
    private LocalDate birthDate = LocalDate.now();

    private String genre;

    private String adresse;

    @Pattern(regexp = "\\d{8}", message = "please enter a valid number")
    private String telephone;

    @Enumerated(EnumType.STRING)
    private Role role;

    @Lob
    @Column(length = 1048576)
    protected byte[] photo;

    @NotBlank(message = "username can't be empty")
    @Column(unique = true)
    protected String username;

    @ManyToMany
    private List<Activity> activities = new ArrayList<>();

    private boolean active = true; // Indique si le compte est activé

    // Ajout d'une activité à la liste
    public void addActivity(Activity activity) {
        if (!this.activities.contains(activity)) {
            this.activities.add(activity);
        }
    }

    // Suppression d'une activité de la liste
    public void removeActivity(Activity activity) {
        this.activities.remove(activity);
    }

    // Implémentation des méthodes de UserDetails
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + this.role.name()));
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // Le compte n'expire jamais dans cette implémentation
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Le compte n'est jamais verrouillé dans cette implémentation
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Les informations d'identification ne sont jamais expirées
    }

    @Override
    public boolean isEnabled() {
        return this.active; // Le compte est actif si la propriété `active` est vraie
    }
}
