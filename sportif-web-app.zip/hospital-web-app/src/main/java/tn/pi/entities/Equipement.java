package tn.pi.entities;

import lombok.*;

import jakarta.persistence.*;

import jakarta.validation.constraints.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder

@Entity
public class Equipement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Le nom de l'équipement ne peut pas être vide")
    private String name;

    @Min(value = 0, message = "La quantité ne peut pas être négative")
    private int quantity;

    @ManyToMany
    @ToString.Exclude // Exclusion pour éviter les récursions infinies
    private List<Activity> activities = new ArrayList<>();

}
