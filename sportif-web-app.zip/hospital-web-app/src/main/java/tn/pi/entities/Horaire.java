package tn.pi.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.validator.constraints.Range;
import tn.pi.enums.DayOfWeek;
import tn.pi.enums.Role;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//Entity indique que cette classe est une table
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
//@ToString
@Builder

public class Horaire {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Le jour est obligatoire")
    @Enumerated(EnumType.STRING)
    private DayOfWeek jour;

    @NotNull(message = "L'heure de début est obligatoire")
    private LocalTime heureDebut;

    @NotNull(message = "L'heure de fin est obligatoire")
    private LocalTime heureFin;


    @ManyToOne
    @JoinColumn(name = "activite_id")
    private Activity activite;
}