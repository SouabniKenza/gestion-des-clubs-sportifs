package tn.pi.web;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import tn.pi.entities.Activity;
import tn.pi.entities.Member;
import tn.pi.enums.Role;
import tn.pi.repositories.ActivityRepo;
import tn.pi.repositories.MemberRepo;
import org.springframework.security.crypto.password.PasswordEncoder;
import tn.pi.repositories.PaymentRepo;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Controller
@Slf4j
public class Member_Controller {
    private final MemberRepo memberRepo;
    private final ActivityRepo activityRepo;
    private final PasswordEncoder passwordEncoder;
    private final PaymentRepo paymentRepo;

    public Member_Controller(MemberRepo memberRepo, ActivityRepo activityRepo, PasswordEncoder passwordEncoder,PaymentRepo paymentRepo) {
        this.memberRepo = memberRepo;
        this.activityRepo = activityRepo;
        this.passwordEncoder = passwordEncoder;
        this.paymentRepo = paymentRepo;
    }

    @GetMapping("/listMembers")
    public String listMembers(Model model,
                              @RequestParam(name = "page", defaultValue = "0") int page,
                              @RequestParam(name = "size", defaultValue = "6") int size,
                              @RequestParam(name = "keyword", defaultValue = "") String keyword,
                              @RequestParam(name = "role", defaultValue = "") Role role,
                              @RequestParam(name = "activityId", required = false) Long activityId,
                              @RequestParam(name = "operation_to_do", defaultValue = "view") String operation_to_do,
                              Principal principal)
    {
        Page<Member> members=null;
        String username;

        // Récupérer le nom d'utilisateur connecté
        if(principal != null)
        {
            username = principal.getName();
            Optional<Member> memberOpt = memberRepo.findByUsername(username);
            if (memberOpt.isPresent())
            {
                Member member = memberOpt.get();
                switch (member.getRole())
                {
                    case COACH:
                        List<Activity> activityList=member.getActivities();
                        members=memberRepo.findMembersByActivities(activityList, PageRequest.of(page, size));
                        model.addAttribute("template", "template2");
                        break;
                    case ADMIN:
                        model.addAttribute("template", "template1");
                        model.addAttribute("activityId", activityId);
                        switch (operation_to_do)
                        {
                            case "add_members_to_activity"://view members who are not in this activity and add them
                                members = memberRepo.findByActivitiesNotContainingAndNameContainingAndRole(activityId,keyword,role, PageRequest.of(page, size));
                                break;
                            case "view_activity_members" ://view an activity's members
                                members = memberRepo.findByActivityAndNameContaining(activityId,keyword, PageRequest.of(page, size));

                                break;
                            case "view_only":
                                if (role != null)
                                    members = memberRepo.findByNomContainsAndRole(keyword, role, PageRequest.of(page, size));
                                else
                                    members = memberRepo.findByNomContains(keyword, PageRequest.of(page, size));
                                break;
                        }
                }
            }
        }
        // Ajouter les données au modèle
        model.addAttribute("members", members != null ? members.getContent() : null);
        model.addAttribute("pages", members != null ? new int[members.getTotalPages()] : new int[1] );
        model.addAttribute("role", role);
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", keyword);
        model.addAttribute("roles", Role.values());
        model.addAttribute("activities", activityRepo.findAll());
        model.addAttribute("operation_to_do", operation_to_do);
        model.addAttribute("coach", true);

        return "members"; // Retourner la vue "members"
    }

    @GetMapping("/delete")
    public String deleteMember(
            @RequestParam(name = "id") Long memberId,
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(name = "activityId", required = false) Long activityId,
            RedirectAttributes redirectAttributes
    )
    {
        if (activityId == null) {

            memberRepo.findById(memberId).ifPresent(member -> {
                paymentRepo.findByMember(member).forEach(payment -> {
                    payment.setMember(null);
                    paymentRepo.save(payment);}
                );
                activityRepo.findByMembersContains(member).forEach(activity -> {
                    activity.removeMember(member);
                    activityRepo.save(activity);}
                );
                memberRepo.save(member);
                memberRepo.flush();
                memberRepo.delete(member);

            });
            redirectAttributes.addAttribute("page", page);
            redirectAttributes.addAttribute("keyword", keyword);
            redirectAttributes.addAttribute("operation_to_do", "view_only");
            return "redirect:/listMembers";
        } else {
            // Supprimer la relation entre membre et activité
            Member member = memberRepo.findById(memberId)
                    .orElseThrow(() -> new IllegalArgumentException("Member not found"));
            Activity activity = activityRepo.findById(activityId)
                    .orElseThrow(() -> new IllegalArgumentException("Activity not found"));
            member.removeActivity(activity);
            activity.removeMember(member);

            memberRepo.save(member);
            activityRepo.save(activity);
            redirectAttributes.addAttribute("page", page);
            redirectAttributes.addAttribute("keyword", keyword);
            redirectAttributes.addAttribute("activityId", activityId);
            redirectAttributes.addAttribute("operation_to_do", "view_activity_members");
            return "redirect:/listMembers";
        }

    }
    @GetMapping("/formMembers")
    public String formMembers(Model model,
                              @RequestParam(name = "signup", required = false, defaultValue = "false") Boolean Signup,
                              @RequestParam(name = "type", required = false, defaultValue = "0") int type
    ) {
        model.addAttribute("member", new Member());
        model.addAttribute("activities", activityRepo.findAll());
        model.addAttribute("signup", Signup);
        model.addAttribute("type",type);
        return "formMembers";
    }
    @GetMapping("/signup")
    public String formMem(Model model) {
        model.addAttribute("roles", Role.values());
        model.addAttribute("member", new Member());
        model.addAttribute("activities", activityRepo.findAll()); // Récupère toutes les activités
        return "signup";
    }
    @PostMapping("/saveMember")
    public String saveMember(@Valid Member member,
                             BindingResult bindingResult,
                             @RequestParam(value = "activities", required = false) List<Long> activityIds,
                             @RequestParam(name = "signup", required = false, defaultValue = "false") Boolean Signup,
                             @RequestParam(name = "type", required = false, defaultValue = "0") int type,
                             Model model,
                             RedirectAttributes redirectAttributes
    ) {
        // Charger les activités et les rôles pour le formulaire
        List<Activity> activities = activityRepo.findAll();
        model.addAttribute("activities", activities);
        model.addAttribute("roles", Role.values());
        if(Signup){
            if (bindingResult.hasErrors() || memberRepo.existsByUsername(member.getUsername()))
            {
                if (memberRepo.existsByUsername(member.getUsername()))
                    bindingResult.rejectValue("username", "error.member", "This username is already taken.");
                if(type!=1)
                    return "signup";
                else
                {
                    model.addAttribute("signup", true);
                    return "formMembers";
                }
            }
            else
            {
                //ajouter les activity si il y en a
                if (activityIds!=null && !activityIds.isEmpty())
                    member.setActivities(activityRepo.findAllById(activityIds));
                member.setPassword(passwordEncoder.encode(member.getPassword()));
                memberRepo.save(member);
                if(type!=1)
                    return "redirect:/login";
                else
                {
                    redirectAttributes.addAttribute("operation_to_do","view_only" );
                    return "redirect:/listMembers";
                }
            }
        }
        else
        {
            if (bindingResult.hasErrors() && member.getPassword()!=null)
            {
                model.addAttribute("signup",false);
                return "formMembers";
            }
            else
            {
                if (activityIds!=null )
                    member.setActivities(activityRepo.findAllById(activityIds));
                memberRepo.save(member);

                redirectAttributes.addAttribute("operation_to_do","view_only" );
                return "redirect:/listMembers";
            }
        }
    }

    @GetMapping("/editMember")
    public String editMember(Model model, @RequestParam(name = "id", required = false) Long id) {
        Member member;

        if (id != null) {
            // Rechercher le membre par ID
            Optional<Member> findOne = memberRepo.findById(id);
            if (findOne.isPresent()) {
                member = findOne.get();
            } else {
                // Si aucun membre n'est trouvé, rediriger ou afficher un message d'erreur
                model.addAttribute("errorMessage", "Member not found with ID: " + id);
                return "errorPage";
            }
        } else {
            // Initialiser un nouveau membre si l'ID n'est pas fourni
            member = new Member();
        }

        // Ajouter le membre et les activités au modèle
        model.addAttribute("member", member);
        model.addAttribute("activities", activityRepo.findAll());
        model.addAttribute("signup", false);
        return "formMembers";
    }

    @GetMapping("/addMemberToActivity")
    public String setActivity(Model model,
                              @RequestParam(name = "memberid") Long memberId,
                              @RequestParam(name = "activityid") Long activityId,
                              RedirectAttributes redirectAttributes
    )
    {
        Optional<Member> memberOpt = memberRepo.findById(memberId);
        Optional<Activity> activityOpt = activityRepo.findById(activityId);
        if (memberOpt.isEmpty() || activityOpt.isEmpty()) {
            model.addAttribute("errorMessage", "Member or Activity not found");
            return "errorPage"; // Remplacez par une vue d'erreur appropriée
        }
        Member member = memberOpt.get();
        Activity activity = activityOpt.get();

        // Ajout de l'activité au membre et vice versa
        member.addActivity(activity);
        activity.addMember(member);

        // Sauvegarde du membre (cascade sur l'activité si configurée)
        memberRepo.save(member);
        redirectAttributes.addAttribute("activityId", activityId  );
        redirectAttributes.addAttribute("operation_to_do","add_members_to_activity" );
        return "redirect:/listMembers";
    }

    @GetMapping("/error")
    public String handleError(@RequestParam(name = "errorMessage", defaultValue = "An error occurred") String errorMessage,
                              Model model) {
        model.addAttribute("errorMessage", errorMessage);
        return "errorPage"; // Remplacez par la vue de votre choix
    }

}
