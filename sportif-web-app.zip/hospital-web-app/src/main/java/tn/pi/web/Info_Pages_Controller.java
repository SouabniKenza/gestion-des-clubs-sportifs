package tn.pi.web;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import tn.pi.entities.Activity;
import tn.pi.entities.Member;
import tn.pi.repositories.ActivityRepo;
import tn.pi.repositories.MemberRepo;

import java.util.Collections;
import java.util.List;

@Controller
public class Info_Pages_Controller {

    private final ActivityRepo activityRepo; // Injection du repository
    private final MemberRepo memberRepo;

    // Constructeur pour injecter ActivityRepo
    public Info_Pages_Controller(ActivityRepo activityRepo , MemberRepo memberRepo) {
        this.activityRepo = activityRepo;
        this.memberRepo = memberRepo;
    }

    @GetMapping("/homeCli")
    public String homePage(Model model) {
        // Récupère toutes les activités depuis le repository
        List<Activity> activities = activityRepo.findAll();
        model.addAttribute("activities", activities);
        return "homeCli"; // Nom du fichier HTML (homeCli.html)
    }
    @GetMapping("/activitiesCli")
    public String activitiesCli(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();  // Ou vous pouvez récupérer des détails plus précis si nécessaire

        // Charger l'utilisateur depuis la base de données (par exemple, avec un service UserService)
        Member currentUser = memberRepo.findByUsername(username).get();
        // Récupère toutes les activités depuis le repository
        List<Activity> activities = activityRepo.findAll();
        model.addAttribute("activities", activities);
        model.addAttribute("list", currentUser != null ? currentUser.getActivities() : Collections.emptyList());

        return "activitiesCli"; // Nom du fichier HTML (homeCli.html)
    }

    @GetMapping("/aboutUs")
    public String aboutUs() {
        return "aboutUs"; // Nom du fichier HTML (aboutUs.html)
    }

    @GetMapping("/contactUs")
    public String contactUs() {
        return "contactUs"; // Nom du fichier HTML (contactUs.html)
    }
}
