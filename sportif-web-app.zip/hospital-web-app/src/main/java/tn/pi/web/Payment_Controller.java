package tn.pi.web;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import tn.pi.entities.Activity;
import tn.pi.entities.Member;
import tn.pi.entities.Payment;
import tn.pi.enums.PaymentStatus;
import tn.pi.repositories.ActivityRepo;
import tn.pi.repositories.MemberRepo;
import tn.pi.repositories.PaymentRepo;

import java.util.List;

@Controller
@Slf4j
public class Payment_Controller {

    @Autowired
    private PaymentRepo paymentRepo;

    @Autowired
    private MemberRepo memberRepo;
    @Autowired
    private ActivityRepo activityRepo;

    @GetMapping("/listPayments")
public String listPayments(
        Model model,
        @RequestParam(name = "page", defaultValue = "0") int page,
        @RequestParam(name = "size", defaultValue = "6") int size,
        @RequestParam(name = "keyword", required = false) String keyword,
        @RequestParam(name = "status", required = false) PaymentStatus status,
        @RequestParam(name = "memberId", required = false) Long memberId) {

    Page<Payment> payments;

    if ( (status != null)) {
        // Si un mot-clé ou un statut est défini
        payments = paymentRepo.findByStatus(
                status == null ? PaymentStatus.PENDING : status,
                PageRequest.of(page, size));
    } else if (memberId != null) {
        // Si on filtre par membre
        payments = paymentRepo.findByMember_Id(memberId, PageRequest.of(page, size));
    } else {
        // Si aucun filtre n'est défini
        payments = paymentRepo.findAll(PageRequest.of(page, size));
    }

    model.addAttribute("payments", payments.getContent());
    model.addAttribute("pages", new int[payments.getTotalPages()]);
    model.addAttribute("currentPage", page);
    model.addAttribute("members", memberRepo.findAll());
    model.addAttribute("selectedMemberId", memberId);
    model.addAttribute("selectedStatus", status);
    model.addAttribute("keyword", keyword);

    return "payments"; // Vue HTML pour afficher la liste des paiements
}
    /**
     * Formulaire pour ajouter/modifier un paiement.
     */


    @GetMapping("/formPayments")
    public String formPayment(
            Model model,
            @RequestParam(value = "id", required = false) Long id,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "inscription", required = false) boolean inscription,
            @RequestParam(name = "size", defaultValue = "6") int size) {
        List<Activity> activityList= activityRepo.findAll();

        Payment payment = (id != null) ? paymentRepo.findById(id).orElse(new Payment()) : new Payment();
        model.addAttribute("payment", payment);
        model.addAttribute("members", memberRepo.findAll());
        model.addAttribute("currentPage", page); // Ajoutez la page actuelle
        model.addAttribute("size", size);       // Ajoutez la taille actuelle
        model.addAttribute("activities", activityList);
        model.addAttribute("inscription", inscription);

        return "formPayments";
    }


    /**
     * Enregistrer un nouveau paiement ou mettre à jour un paiement existant.
     */
    @PostMapping("/savePayment")
    public String savePayment(@Valid Payment payment, BindingResult bindingResult, Model model, @RequestParam(name = "inscription",required = false) boolean inscription,
                              @RequestParam(name = "id-details",required = false) Long id) {
        if (bindingResult.hasErrors() && !inscription) {
            System.out.println(bindingResult.getAllErrors());
            model.addAttribute("members", memberRepo.findAll());
            model.addAttribute("template","template1");
            return "formPayments";
        }
        paymentRepo.save(payment);
        if(inscription) {
            Member member= memberRepo.findById(payment.getMember().getId()).get();
            Activity activity= activityRepo.findById(id).get();
            member.addActivity(activity);
            activity.addMember(member);
            activityRepo.save(activity);
            memberRepo.save(member);
            return "redirect:/activitiesCli";
        }
        model.addAttribute("template","template1");
        return "redirect:/listPayments";
    }




    /**
     * Supprimer un paiement par ID.
     */
    @GetMapping("/deletePayment")
    public String deletePayment(@RequestParam(name = "id") Long id) {
        paymentRepo.deleteById(id);
        return "redirect:/listPayments";
    }


    @GetMapping("/editPayment")
    public String editPayment (Model model, @RequestParam(name = "id") Long id){
        Payment payment = paymentRepo.findById(id).get();
        model.addAttribute("payment",payment);
        model.addAttribute("payments", paymentRepo.findAll());

        return "formPayments";
    }
}
