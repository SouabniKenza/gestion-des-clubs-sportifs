package tn.pi.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Profile_Controller {

    @GetMapping("/editProfile")
    public String profileForm() {
        return "editProfile"; // Vue correspondante
    }

}