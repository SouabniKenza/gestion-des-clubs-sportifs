package tn.pi.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import tn.pi.entities.Activity;
import tn.pi.repositories.ActivityRepo;

import java.util.Optional;

@RestController
@RequestMapping("/images")
public class Image_Controller {

    @Autowired
    private ActivityRepo activityRepo;

    @GetMapping("/image")
    public ResponseEntity<ByteArrayResource> getImage(@RequestParam Long id) {
        Optional<Activity> activity = activityRepo.findById(id);

        if (activity.isPresent() && activity.get().getImage() != null) {
            byte[] imageData = activity.get().getImage();
            ByteArrayResource resource = new ByteArrayResource(imageData);

            // Retourne l'image avec le type MIME approprié
            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG) // Modifiez selon le type d'image (JPEG, PNG, etc.)
                    .body(resource);
        } else {
            return ResponseEntity.notFound().build(); // Retourne 404 si l'image n'est pas trouvée
        }
    }
}
