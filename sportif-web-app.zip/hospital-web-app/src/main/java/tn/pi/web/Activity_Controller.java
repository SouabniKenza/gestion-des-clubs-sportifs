package tn.pi.web;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import tn.pi.entities.Activity;
import tn.pi.entities.Horaire;
import tn.pi.entities.Member;
import tn.pi.entities.Payment;
import tn.pi.enums.DayOfWeek;
import tn.pi.repositories.ActivityRepo;
import tn.pi.repositories.HoraireRepo;
import tn.pi.repositories.MemberRepo;
import tn.pi.security.SecurityUtil;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalTime;
import java.util.List;

@Controller
@Slf4j
public class Activity_Controller {

    private final ActivityRepo activityRepo;
    private final HoraireRepo horaireRepo;
    private final MemberRepo memberRepo;
    @Autowired
    public Activity_Controller(ActivityRepo activityRepo, HoraireRepo horaireRepo, MemberRepo memberRepo) {
        this.activityRepo = activityRepo;
        this.horaireRepo = horaireRepo;
        this.memberRepo=memberRepo;
    }

    @GetMapping("/listActivities")
    public String listActivities(
            Model model,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "5") int size,
            @RequestParam(name = "keyword", defaultValue = "") String keyword,
            @RequestParam(name = "payment",required = false) boolean payement) {

        Page<Activity> activities = activityRepo.findByNameContains(keyword, PageRequest.of(page, size));

        model.addAttribute("activities", activities.getContent());
        model.addAttribute("pages", new int[activities.getTotalPages()]);
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", keyword);
        model.addAttribute("payment", payement);
        return "activities"; // Vue HTML pour afficher la liste des activités
    }


    @GetMapping("/deleteActivity")
    public String deleteActivity(Long id,  String keyword, int page) {
        activityRepo.deleteById(id);
        return "redirect:/listActivities?page=" + page + "&keyword=" + keyword;
    }

    @GetMapping("/formActivities")
    public String formActivity(Model model) {
        model.addAttribute("activity", new Activity());
        return "formActivities"; // Vue HTML pour le formulaire d'activité
    }

    @PostMapping("/saveActivity")
    public String saveActivity(@Valid @ModelAttribute Activity activity,
                               BindingResult bindingResult,
                               Model model) {
        // Vérifiez les erreurs de validation
        if (bindingResult.hasErrors()) {
            System.out.println("Binding errors: " + bindingResult.getAllErrors());
            model.addAttribute("activity", activity);
            return "formActivities";
        }

        try {
            // Validation du fichier image (si fourni)
            MultipartFile photoFile = activity.getImageFile();
            if (photoFile != null && !photoFile.isEmpty()) {
                if (photoFile.getSize() > 1048576) { // 1 Mo
                    bindingResult.rejectValue("imageFile", "error.activity", "La taille de l'image dépasse 1 Mo.");
                    model.addAttribute("activity", activity);
                    return "formActivities";
                }
                if (!photoFile.getContentType().startsWith("image/")) {
                    bindingResult.rejectValue("imageFile", "error.activity", "Le fichier doit être une image.");
                    model.addAttribute("activity", activity);
                    return "formActivities";
                }

                // Convertir le fichier en bytes
                activity.setImage(photoFile.getBytes());
            }
        } catch (IOException e) {
            bindingResult.rejectValue("imageFile", "error.activity", "Erreur lors du traitement de l'image.");
            model.addAttribute("activity", activity);
            return "formActivities";
        }

        // Sauvegarder l'entité dans la base
        activityRepo.save(activity);

        // Préparer un nouvel objet pour le formulaire
        model.addAttribute("activity", new Activity());
        return "redirect:/listActivities";
    }



    /**
     * Affiche le formulaire pour modifier une activité existante.
     */
    @GetMapping("/activity/horaires")
    public String getActivityHoraires(@RequestParam Long activityId, Model model) {
        Activity activity = activityRepo.findById(activityId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid activity ID: " + activityId));
        List<Horaire> horaires = horaireRepo.findOrderedHorairesByActivite_Id(activityId);

        model.addAttribute("activity", activity);
        model.addAttribute("horaires", horaires);

        return "activity-horaires"; // Vue HTML pour afficher la liste des horaires
    }
    @GetMapping("/editActivity")
    public String editActivity(@RequestParam(name = "id") Long id, Model model) {
        Activity activity = activityRepo.findById(id).get();
        model.addAttribute("activity", activity);
        return "formActivities"; // Vue HTML pour le formulaire d'activité
    }
    @PostMapping("/activity/horaires/add")
    public String addHoraire(@RequestParam Long activityId,
                             @RequestParam String jour,
                             @RequestParam String heureDebut,
                             @RequestParam String heureFin,
                             Model model) {

        Activity activity = activityRepo.findById(activityId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid activity ID: " + activityId));

        Horaire horaire = new Horaire();
        horaire.setActivite(activity);
        horaire.setJour(DayOfWeek.valueOf(jour.toUpperCase()));
        horaire.setHeureDebut(LocalTime.parse(heureDebut));
        horaire.setHeureFin(LocalTime.parse(heureFin));

        horaireRepo.save(horaire);

        model.addAttribute("message", "Voulez-vous ajouter un autre horaire ?");
        model.addAttribute("activityId", activityId);

        return "confirm-add-horaire"; // Vue HTML avec confirmation
    }


    @GetMapping("/activity/details")
    public String activityDetails(@RequestParam(name = "id") Long id, Model model, Principal principal) {
        Activity activity = activityRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Activité introuvable: " + id));
        List<Horaire> horaires = horaireRepo.findByActivite_Id(id);
        String username =principal.getName();
        Member member=null;
        // Récupérer le nom d'utilisateur connecté et remplir les infos
        if(principal != null)
        {
            if(memberRepo.findByUsername(username).isPresent())
                member = memberRepo.findByUsername(username).get();
        }
        model.addAttribute("activity", activity);
        model.addAttribute("horaires", horaires);
        model.addAttribute("isloged", SecurityUtil.isUserLoggedIn()); // Si cette vérification est déjà faite ailleurs, utilisez la méthode existante
        model.addAttribute("member", member);
        model.addAttribute("paiement", new Payment());
        return "activity-details";
    }



}




