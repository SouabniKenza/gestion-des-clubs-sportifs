package tn.pi.web;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import tn.pi.entities.Activity;
import tn.pi.entities.Horaire;
import tn.pi.entities.Member;
import tn.pi.enums.DayOfWeek;
import tn.pi.enums.Role;
import tn.pi.repositories.ActivityRepo;
import tn.pi.repositories.HoraireRepo;
import tn.pi.repositories.MemberRepo;

import java.security.Principal;
import java.time.LocalTime;
import java.util.List;

@Controller
public class Plan_Controller {
    private final ActivityRepo activityRepo;
    private final HoraireRepo horaireRepo;
    private final MemberRepo memberRepo;

    public Plan_Controller(ActivityRepo activityRepo, HoraireRepo horaireRepo, MemberRepo memberRepo) {
        this.activityRepo = activityRepo;
        this.horaireRepo = horaireRepo;
        this.memberRepo = memberRepo;
    }

    // Affiche les activités pour gérer les horaires
    @GetMapping("/admin/plan")
    public String listActivities(Model model) {
        model.addAttribute("activities", activityRepo.findAll());
        return "admin-plan"; // Vue HTML
    }

    // Page pour ajouter un horaire
    @GetMapping("/admin/plan/add")
    public String addHoraireForm(@RequestParam Long activityId, Model model) {
        model.addAttribute("activity", activityRepo.findById(activityId).orElseThrow());
        return "add-horaire"; // Vue HTML
    }

    // Sauvegarde un horaire
    @PostMapping("/admin/plan/add")
    public String addHoraire(@RequestParam Long activityId, @RequestParam String jour,
                             @RequestParam String heureDebut, @RequestParam String heureFin, Model model) {
        Activity activity = activityRepo.findById(activityId).orElseThrow();
        Horaire horaire = new Horaire();
        horaire.setActivite(activity);
        horaire.setJour(DayOfWeek.valueOf(jour));
        horaire.setHeureDebut(LocalTime.parse(heureDebut));
        horaire.setHeureFin(LocalTime.parse(heureFin));
        horaireRepo.save(horaire);

        model.addAttribute("message", "Voulez-vous ajouter un autre horaire ?");
        model.addAttribute("activityId", activityId);
        return "confirm-add-horaire"; // Vue HTML avec confirmation
    }


    // Liste des horaires pour une activité
    @GetMapping("/admin/plan/horaires")
    public String listHoraires(@RequestParam Long activityId, Model model) {
        model.addAttribute("horaires", horaireRepo.findOrderedHorairesByActivite_Id(activityId));
        return "list-horaires"; // Vue HTML
    }


    //lister tout les plans avec filtrage dans Plan
@GetMapping("/listPlans")
public String listPlans(@RequestParam(required = false) Long activityId,
                        @RequestParam(required = false) String jour, Principal principal,
                        @RequestParam(name = "myplan",required = false) boolean myplan,
                        Model model) {
    List<Horaire> horaires;
    List<Activity> activities = activityRepo.findAll();;
    List<String> jours = horaireRepo.findDistinctJours(); // Méthode à ajouter dans HoraireRepo
    String username;
    Member member=null;
    // Récupérer le nom d'utilisateur connecté
    if(principal != null)
    {
        username = principal.getName();
        member = memberRepo.findByUsername(username).get();
        if(member != null && member.getRole()== Role.COACH)
        {
            model.addAttribute("template", "template2");
        }
        if(member != null && member.getRole()== Role.ADHERENT)
        {
            model.addAttribute("template", "template2");
        }
        if(member != null && member.getRole()== Role.ADMIN)
        {
            model.addAttribute("template", "template1");
        }
    }

    if(myplan && member != null)
    {
        activities = member.getActivities();
    }
    if ((activityId == null || activityId == 0) && (jour == null || jour.isEmpty() || "All".equals(jour))) {
        // Aucun filtre ou filtre "All" : afficher tous les horaires
        horaires = horaireRepo.findAll();
    } else if (activityId != null && activityId != 0 && (jour == null || "All".equals(jour))) {
        // Filtrer uniquement par activité
        horaires = horaireRepo.findByActivite_Id(activityId);
    } else if (activityId == null || activityId == 0) {
        // Filtrer uniquement par jour
        horaires = horaireRepo.findByJour(DayOfWeek.valueOf(jour));
    } else {
        // Filtrer par activité et jour
        horaires = horaireRepo.findByActivite_IdAndJour(activityId, DayOfWeek.valueOf(jour));
    }



    model.addAttribute("horaires", horaires);
    model.addAttribute("activities", activities);
    model.addAttribute("jours", jours);
    model.addAttribute("selectedActivityId", activityId);
    model.addAttribute("selectedJour", jour);

    return "list-plans";
}


@GetMapping("/editPlan")
public String showEditPlanForm(@RequestParam Long id, Model model) {
    Horaire horaire = horaireRepo.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid plan ID: " + id));
    model.addAttribute("horaire", horaire);
    model.addAttribute("jours", List.of(DayOfWeek.values())); // Liste des jours disponibles
    return "formPlan"; // Vue HTML pour le formulaire
}

    @PostMapping("/editPlan")
    public String updatePlan(@RequestParam Long id,
                             @RequestParam String jour,
                             @RequestParam String heureDebut,
                             @RequestParam String heureFin) {
        Horaire horaire = horaireRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid plan ID: " + id));
        horaire.setJour(DayOfWeek.valueOf(jour));
        horaire.setHeureDebut(LocalTime.parse(heureDebut));
        horaire.setHeureFin(LocalTime.parse(heureFin));
        horaireRepo.save(horaire);
        return "redirect:/listPlans"; // Retour à la liste des plans
    }


    @PostMapping("/deletePlan")
    public String deletePlan(@RequestParam Long id, Model model) {
        horaireRepo.deleteById(id);
        List<Horaire> horaires = horaireRepo.findAll(); // Recharger la liste des horaires
        model.addAttribute("horaires", horaires);
        model.addAttribute("message", "L'horaire a été supprimé avec succès.");
        return "redirect:/listPlans";
    }


}
