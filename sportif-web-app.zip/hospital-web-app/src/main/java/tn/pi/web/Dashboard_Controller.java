package tn.pi.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import tn.pi.enums.Role;
import tn.pi.repositories.MemberRepo;
import tn.pi.repositories.PaymentRepo;
import tn.pi.repositories.ActivityRepo;

import java.util.List;
@Controller
public class Dashboard_Controller {

    private final MemberRepo memberRepo;
    private final PaymentRepo paymentRepo;
    private final ActivityRepo activityRepo;

    public Dashboard_Controller(MemberRepo memberRepo, PaymentRepo paymentRepo, ActivityRepo activityRepo) {
        this.memberRepo = memberRepo;
        this.paymentRepo = paymentRepo;
        this.activityRepo = activityRepo;
    }

    @GetMapping("/dashAdmin")
    public String adminDashboard(Model model) {
        // Données de base
        long totalMembers = memberRepo.count();
        long totalPayments = paymentRepo.count();
        long totalActivities = activityRepo.count();


        // Membres par rôle
        long totalAdherents = memberRepo.countByRole(Role.ADHERENT);
        long totalCoaches = memberRepo.countByRole(Role.COACH);


        // Activités populaires
        List<Object[]> popularActivities = memberRepo.findMostPopularActivities();


        // Ajouter au modèle
        model.addAttribute("totalMembers", totalMembers);
        model.addAttribute("totalPayments", totalPayments);
        model.addAttribute("totalActivities", totalActivities);
        model.addAttribute("totalAdherents", totalAdherents);
        model.addAttribute("totalCoaches", totalCoaches);
        model.addAttribute("popularActivities", popularActivities);

        return "dashAdmin";
    }
}
