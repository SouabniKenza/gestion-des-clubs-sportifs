package tn.pi.web;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import tn.pi.entities.Activity;
import tn.pi.entities.Member;
import tn.pi.entities.Payment;
import tn.pi.repositories.ActivityRepo;
import tn.pi.repositories.MemberRepo;


import java.time.LocalDate;

@Controller
@Slf4j

@RequestMapping("/adherent")
public class Adherent_Controller {
    @Autowired
    private ActivityRepo activityRepo;
    @Autowired
    private MemberRepo memberRepo;



    @GetMapping("/home")
    public String redirect3() {
        return "redirect:/homeCli";
    }
    @GetMapping("/myactivity")
    public String list(
            Model model,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "5") int size,
            @RequestParam(name = "keyword", defaultValue = "") String keyword) {

        // Récupérer l'utilisateur connecté
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();  // Ou vous pouvez récupérer des détails plus précis si nécessaire

        // Charger l'utilisateur depuis la base de données (par exemple, avec un service UserService)
        Member currentUser = memberRepo.findByUsername(username).get();

        // Rechercher les activités avec pagination et recherche par mot-clé
        Page<Activity> activities = activityRepo.findByNameContainsAndMembers(keyword,currentUser, PageRequest.of(page, size));

        // Passer les données au modèle
        model.addAttribute("activities", activities.getContent());
        model.addAttribute("pages", new int[activities.getTotalPages()]);
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", keyword);
        model.addAttribute("currentUser", currentUser); // Ajout des données de l'utilisateur connecté

        return "adh-activity"; // Vue HTML pour afficher la liste des activités
    }

    @GetMapping("/subscribe")
    public String suscribeActivities(Model model,@RequestParam(name = "activityid", defaultValue = "") Long activityid,@RequestParam(name = "userid", defaultValue = "") Long userid)
    {
        Activity activity= activityRepo.findById(activityid).get();
        Member member= memberRepo.findById(userid).get();
        Payment payment = new Payment();
        model.addAttribute("activity", activity);
        model.addAttribute("member", member);
        model.addAttribute("payment", payment);
        model.addAttribute("Date", LocalDate.now());
        return "suscribe";
    }

    @GetMapping("/leave")
    public String leaveActivities(Model model,@RequestParam(name = "activityid", defaultValue = "") Long activityid,@RequestParam(name = "userid", defaultValue = "") Long userid)
    {
        Activity activity= activityRepo.findById(activityid).get();
        Member member= memberRepo.findById(userid).get();
        member.removeActivity(activity);
        activity.removeMember(member);
        activityRepo.save(activity);
        memberRepo.save(member);
        return "redirect:/adherent/myactivity";
    }

}
