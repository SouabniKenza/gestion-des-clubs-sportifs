package tn.pi.web;
//Le contrôleur permet de gérer les fonctionnalités liées aux équipements, y compris l'affichage, la création, la modification et la suppression des équipements, ainsi que leur association avec des activités.
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import tn.pi.entities.Equipement;
import tn.pi.entities.Activity;
import tn.pi.repositories.EquipementRepo;
import tn.pi.repositories.ActivityRepo;

import java.util.List;

@Controller
@Slf4j
public class Equipment_Controller {

    private final EquipementRepo equipementRepo;
    private final ActivityRepo activityRepo;

    @Autowired
    public Equipment_Controller(EquipementRepo equipementRepo, ActivityRepo activityRepo) {
        this.equipementRepo = equipementRepo;
        this.activityRepo = activityRepo;
    }



    /**
     * Affiche la liste des équipements avec pagination et recherche par mot-clé.
     */
//    @GetMapping("/listEquipements")
//    public String listEquipements(Model model,
//                                  @RequestParam(name = "page", defaultValue = "0") int page,
//                                  @RequestParam(name = "size", defaultValue = "5") int size,
//                                  @RequestParam(name = "keyword", defaultValue = "") String keyword) {
//        Page<Equipement> equipements = equipementRepo.findByNameContains(keyword, PageRequest.of(page, size));
//        //Récupérer les équipements associés
//
//
//        model.addAttribute("equipements", equipements.getContent());
//        model.addAttribute("pages", new int[equipements.getTotalPages()]);
//        model.addAttribute("currentPage", page);
//        model.addAttribute("keyword", keyword);
//
//        return "equipements"; // Vue HTML pour afficher la liste des équipements
//    }


    @GetMapping("/listEquipements")
    public String listEquipements(
            Model model,
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "6") int size,
            @RequestParam(name = "keyword", defaultValue = "") String keyword,
            @RequestParam(name = "activityId", required = false) Long activityId) {

        Page<Equipement> equipements;

        if (activityId != null) {
            // Filtrer les équipements par activité spécifique
            equipements = equipementRepo.findByActivities_Id(activityId, PageRequest.of(page, size));
            model.addAttribute("activityId", activityId); // Pour indiquer l'activité dans la vue
        } else {
            // Sinon, afficher tous les équipements
            equipements = equipementRepo.findByNameContains(keyword, PageRequest.of(page, size));
        }

        model.addAttribute("equipements", equipements.getContent());
        model.addAttribute("pages", new int[equipements.getTotalPages()]);
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", keyword);

        return "equipements"; // Vue pour afficher les équipements
    }


    /**
     * Supprime un équipement par son ID.
     */
    @GetMapping("/deleteEquipement")
    public String deleteEquipement(@RequestParam(name = "id") Long id,
                                   @RequestParam(name = "keyword", defaultValue = "") String keyword,
                                   @RequestParam(name = "page", defaultValue = "0") int page) {
        equipementRepo.deleteById(id);
        return "redirect:/listEquipements?page=" + page + "&keyword=" + keyword;
    }

    /**
     * Affiche le formulaire pour ajouter un nouvel équipement.
     */
    @GetMapping("/formEquipements")
    public String formEquipement(Model model) {
        model.addAttribute("equipement", new Equipement());
        List<Activity> activities = activityRepo.findAll();
        model.addAttribute("activities", activities);
        return "formEquipements"; // Vue HTML pour le formulaire d'équipement
    }

    /**
     * Enregistre un nouvel équipement ou met à jour un équipement existant.
     */
    @PostMapping("/saveEquipement")
    public String saveEquipement(@Valid Equipement equipement, BindingResult bindingResult,
                                 @RequestParam(value = "activityIds", required = false) List<Long> activityIds,
                                 Model model) {
        if (bindingResult.hasErrors()) {
            List<Activity> activities = activityRepo.findAll();
            model.addAttribute("activities", activities);
            return "formEquipements";
        }

        // Associer les activités sélectionnées
        if (activityIds != null) {
            List<Activity> activities = activityRepo.findAllById(activityIds);
            equipement.setActivities(activities);
        }

        equipementRepo.save(equipement);
        return "redirect:/listEquipements";
    }

    /**
     * Affiche le formulaire pour modifier un équipement existant.
     */

    @GetMapping("/editEquipement")
    public String editEquipement(@RequestParam(name = "id") Long id, Model model) {
    Equipement equipement = equipementRepo.findById(id).get();
        List<Activity> activities = activityRepo.findAll();

        model.addAttribute("equipement", equipement);
        model.addAttribute("activities", activities); // bch kif namel edit yokhrjouli eli déjà séléctionner


    return "formEquipements"; // Vue HTML pour le formulaire d'activité
}




}